package com.example.payment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    NumberPicker number;
    RadioGroup radioGroup;
    int amount = 0;
    Button lets;
    String  str;
    LinearLayout jjj,yyy,iii;
    RadioButton Googlepay,paytm,phonepay,Amazonpay,money,cloth,food;
    TextView text,kkk;
    EditText a1,a2;
    ConstraintSet q1;
    ConstraintLayout constraintLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number = findViewById(R.id.number);
        number.setMaxValue(1000000007);
        number.setMinValue(1);
        text = findViewById(R.id.amount);
        lets = findViewById(R.id.d1);
        iii=findViewById(R.id.y1);
        jjj=findViewById(R.id.xl);
        yyy=findViewById(R.id.cloth2);
        kkk=findViewById(R.id.t3);
        a1=findViewById(R.id.quantity);
        a2=findViewById(R.id.location);
        q1= new ConstraintSet();
        constraintLayout = (ConstraintLayout) findViewById(R.id.mainactivity);

        lets.setOnClickListener(new View.OnClickListener(

        ) {
            @Override
            public void onClick(View v) {
                if (str.equals("money")) {
                    int tp = number.getValue();
                    amount += tp;
                    text.setText("Rs " + String.valueOf(amount));
                    Toast.makeText(v.getContext(), "You Donate Rs " + String.valueOf(tp) + " recently", Toast.LENGTH_SHORT).show();
                }
                else if(str.equals("cloth")){
                    String t=a1.getText().toString();
                    String r=a2.getText().toString();
                    text.setText("No. of cloths " + a1);
                }
                else{
                    String t=a1.getText().toString();
                    String r=a2.getText().toString();
                    text.setText("quantity of food " + a1);
                }
            }
        });


    }
    public void buttonclicked(View view)
    {
        boolean check  = ((RadioButton) view).isChecked();
        switch (view.getId())
        {
            case R.id.Googlepay:
                Toast.makeText(this,"You selected Google Pay",Toast.LENGTH_SHORT).show();
                break;
            case R.id.paytm:
                Toast.makeText(this,"You selected Paytm ",Toast.LENGTH_SHORT).show();
                break;
            case R.id.Amazonpay:
                Toast.makeText(this,"You selected Amazon Pay",Toast.LENGTH_SHORT).show();
                break;
            case R.id.phonepay:
                Toast.makeText(this,"You selected Phone Pay",Toast.LENGTH_SHORT).show();
                break;
            case R.id.money:
                str="money";

                kkk.setVisibility(View.VISIBLE);
                jjj.setVisibility(View.VISIBLE);
                yyy.setVisibility(View.GONE);
                q1.connect(R.id.y1,ConstraintSet.BOTTOM,R.id.xl,ConstraintSet.TOP,5);
                q1.applyTo(constraintLayout);
                Toast.makeText(this,"You selected to donate money",Toast.LENGTH_SHORT).show();
                break;
            case R.id.cloth:
                str="cloth";
                kkk.setVisibility(View.GONE);
                jjj.setVisibility(View.GONE);
                yyy.setVisibility(View.VISIBLE);
                q1.connect(R.id.y1,ConstraintSet.TOP,R.id.cloth2,ConstraintSet.BOTTOM,5);
                q1.applyTo(constraintLayout);
                Toast.makeText(this,"You selected Clothes",Toast.LENGTH_SHORT).show();
                break;
            case R.id.food:
                str="food";
                kkk.setVisibility(View.GONE);
                jjj.setVisibility(View.GONE);
                yyy.setVisibility(View.VISIBLE);
                q1.connect(R.id.y1,ConstraintSet.TOP,R.id.cloth2,ConstraintSet.BOTTOM,5);
                q1.applyTo(constraintLayout);
                Toast.makeText(this,"You selected food",Toast.LENGTH_SHORT).show();
                break;
        }
    }

}