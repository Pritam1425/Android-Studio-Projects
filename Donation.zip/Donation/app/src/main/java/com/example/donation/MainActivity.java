package com.example.donation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    String flag = "";
    Spinner spinner;
    EditText et1;
    TextView tv1;
    RadioButton rb1;
    RadioButton rb2;
    EditText et2;
    TextView tv2;
    EditText et3;
    TextView tv3;
    Button bt1;
    TextView tv4;
    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Views and variables

        spinner = (Spinner) findViewById(R.id.donationType);
        et1 = (EditText) findViewById(R.id.others);
        tv1 = (TextView) findViewById(R.id.payment);
        rb1 = (RadioButton) findViewById(R.id.radio1);
        rb2 = (RadioButton) findViewById(R.id.radio2);
        et2 = (EditText) findViewById(R.id.amount);
        tv2 = (TextView) findViewById(R.id.locationText);
        et3 = (EditText) findViewById(R.id.location);
        tv3 = (TextView) findViewById(R.id.donationAmount);
        bt1 = (Button) findViewById(R.id.donateButton);
        tv4 = (TextView) findViewById(R.id.donationLocation);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.donation_type,android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);


        AdapterView.OnItemSelectedListener onitemselect = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long id) {
                Object item = adapterView.getItemAtPosition(pos);
                String donationType = item.toString();
                flag = donationType;
                Log.i(TAG, donationType);
                if(donationType.equals("Money")){
                    tv1.setVisibility(View.VISIBLE);
                    tv4.setVisibility(View.GONE);
                    rb1.setVisibility(View.VISIBLE);
                    rb2.setVisibility(View.VISIBLE);
                    et2.setHint("Donate amount in Rs.");
                    tv2.setVisibility(View.GONE);
                    et3.setVisibility(View.GONE);
                }
                else if(donationType.equals("Raw Foods")){
                    et2.setHint("Donate amount in kg");
                    tv2.setVisibility(View.VISIBLE);
                    et3.setVisibility(View.VISIBLE);
                    tv4.setVisibility(View.VISIBLE);
                    tv1.setVisibility(View.GONE);
                    rb1.setVisibility(View.GONE);
                    rb2.setVisibility(View.GONE);
                }
                else {
                    et2.setHint("Donate amount in no of dresses");
                    tv2.setVisibility(View.VISIBLE);
                    et3.setVisibility(View.VISIBLE);
                    tv4.setVisibility(View.VISIBLE);
                    tv1.setVisibility(View.GONE);
                    rb1.setVisibility(View.GONE);
                    rb2.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };

        spinner.setOnItemSelectedListener(onitemselect);


        bt1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String amount = et2.getText().toString();
                        String location = et3.getText().toString();
                        if(flag.equals("Money")){
                            tv3.setText("Donation Amount is Rs. "+amount);
                        }
                        else if(flag.equals("Raw Foods")){
                            tv3.setText("Donation Amount is "+amount+" kg");
                            tv4.setText("Pick up location is "+location);
                        }
                        else{
                            tv3.setText("Donation Amount is "+amount+" shirts");
                            tv4.setText("Pick up location is "+location);
                        }
                    }
                }
        );

    }
    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio1:
                if (checked)
                    break;
            case R.id.radio2:
                if (checked)
                    break;
        }
    }
}