package com.example.mycolddrinkapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner sp;
    Button bt;
    TextView tw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner sp=findViewById(R.id.spinner);
        final Button bt=findViewById(R.id.button);
        final TextView tw=findViewById(R.id.textView);
        ArrayList<String> al=new ArrayList<String>();
        al.add("300ml cold-drink");
        al.add("500ml cold drink");
        al.add("1L cold-drink");
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, al);
        sp.setAdapter(ad);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(position==0)
                        {
                            tw.setText("COCOCOLA");
                        }
                        else  if(position==1)
                        {
                            tw.setText("MOUNTAIN DEW");
                        }
                        if(position==2)
                        {
                            tw.setText("LEMICA");
                        }
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}